public class FirstJava {
    public static void main(String[] args) {
        System.out.println("My name is Coding Dojo");
        System.out.println("I am 100 years old");
        System.out.println("My hometown is Burbank, CA");
    }
}