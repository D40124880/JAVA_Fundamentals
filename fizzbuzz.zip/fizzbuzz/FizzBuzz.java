public class FizzBuzz {
    public static void main(String[] args) {
        Importing id = new Importing();
        String word = id.theBuzz(2);
        System.out.println("The result is: " + word);
    }
}
