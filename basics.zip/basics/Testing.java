public class Testing {
    public static void main(String[] args) {
        Importing thing = new Importing();

        // thing.printOneTo255();
        // thing.printOddTo255();
        // thing.printSumTo255();

        int[] myArray = {1, 3, 5, 7, 12, -5, 9, 13, -3};

        // int[] myArray = {1,3,6};        
        // thing.iterateArry(myArray);
        // thing.findMax(myArray);
        // thing.getAverage(myArray2);
        // thing.arrWithOddNums();
        // int y = 0;
        // thing.greaterThanY(myArray, y);
        // thing.squareTheValues(myArray);
        // thing.elimNegNums(myArray);
        // thing.maxMinAvg(myArray);

        thing.shiftArrVals(myArray);
    }
}
