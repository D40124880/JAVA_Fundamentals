public class Theorem {
    public static void main(String[] args) {
        Importing num = new Importing();
        double newNum = num.theTheorem(25, 77);
        System.out.println("The result is: " + newNum);
    }
}
