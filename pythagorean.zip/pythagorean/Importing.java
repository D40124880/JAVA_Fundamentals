import java.lang.Math;

public class Importing {
    public double theTheorem(int num1, int num2) {
        double calc = Math.sqrt((Math.pow(num1, 2)) + (Math.pow(num2, 2)));
        return calc;
    }
}
